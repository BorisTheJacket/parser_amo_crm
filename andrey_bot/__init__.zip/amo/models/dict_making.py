

class DictMaking():
    
    def __init__(self):
        load_json = None
        self.load_json = load_json

    def get_responsable(self, item):
        json_data = self.load_json
        dict